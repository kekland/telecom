Encode_Blocks : encode_blocks.cpp
Decode_Blocks : decode_blocks.cpp

Compiler Flags : -Wall -O2
Compiler : G++ (Linux)

Tested like :
encode_blocks.out TEST.in OUT.out 1

