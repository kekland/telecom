Source Code : b.cpp

Executable (Tested on Fedora 26) : b.out

Compiler flags : -Wall -O2
Compiler : Default G++ (Linux)

Tested in Gnome Terminal like so :
./b.out <in.dat >out.dat
