Source Code : a.cpp

Executable (Tested on Fedora 26) : a.out

Compiler flags : -Wall -O2
Compiler : Default G++ (Linux)

Tested in Gnome Terminal like so :
./a.out <in.dat >out.dat
